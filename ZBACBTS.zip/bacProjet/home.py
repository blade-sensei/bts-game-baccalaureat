from tkinter import*


def lancer_serveur():
    
    exec(open('serveur.py',encoding='utf-8').read())

def lancer_client():

    x=1



fenetre = Tk()
fenetre.title("Home")
fenetre['bg']='Red'

Frame1 = Frame(fenetre)
Frame1.pack(fill=BOTH)

btn_serveur = Button(Frame1, text="Creer serveur", command=lancer_serveur)
btn_serveur.grid(row=0,column=0)

btn_client = Button(Frame1, text="rejoindre partie")
btn_client.grid(row=0,column=1)

fenetre.mainloop()
